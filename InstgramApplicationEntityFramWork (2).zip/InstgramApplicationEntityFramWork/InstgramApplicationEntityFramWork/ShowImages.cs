﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace InstgramApplicationEntityFramWork
{
    public partial class ShowImages : Form
    {
        public ShowImages()
        {
            InitializeComponent();
        }

        private void ShowImages_Load(object sender, EventArgs e)
        {
            instagramEntities db = new instagramEntities();
            int y = 100;
            foreach (doc d in db.docs)
            {
                PictureBox p = new PictureBox();
                p.Size = new Size(200, 200);
                p.Location = new Point(100, y);
                p.BackgroundImageLayout = ImageLayout.Stretch;
                
                DirectoryInfo dir = new DirectoryInfo(Environment.CurrentDirectory);

                p.SizeMode = PictureBoxSizeMode.StretchImage;

                string pathdir = dir.Parent.Parent.FullName;
                p.Image = Image.FromFile( pathdir+ d.document);


                Label label = new Label();
                label.Text = d.caption;
                label.Location = new Point(100, y + 210);

                y = y + 250;

                this.Controls.Add(p);
                this.Controls.Add(label);
            }

        }

        private void btnMain_Click(object sender, EventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
        }
    }
}
